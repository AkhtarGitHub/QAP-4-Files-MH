# Description: Program for The One Stop Insurance Company to enter and calculate new insurance policy information for its customers.
# Author: Mohammad
# Date(s): March 21 2024


# Define required libraries.
import datetime
import FormatValues as FV
import time
import sys
from datetime import datetime, timedelta


# Define program constants.
# Open the defaults file and read the values into variables
f = open('Defaults.dat', 'r')
NEXT_POLICY_NUM = int(f.readline())
BASIC_PREMIUM = float(f.readline())
DISCOUNT_ADD_CAR = float(f.readline())
EXTRA_LIABILITY_1M_COST = float(f.readline())
GLASS_COVERAGE_COST = float(f.readline())
LOANER_CAR_COST = float(f.readline())
HST_RATE = float(f.readline())
PROCESSING_FEE_MONTH = float(f.readline())
f.close()


# Define program functions.

# Main program starts here.
# Loop to allow entering multiple customers
while True:
    
    # Gather user inputs for customer information details
    CustFirstName = input("Enter the customer first name (END to quit): ").title()
    if CustFirstName.upper() == "END":
        break
    CustLastName = input("Enter the customer last name (END to quit): ").title()
    Address = input("Enter address: ").title()
    City = input("Enter city: ").title()

    ProvLst = ["NL", "NS", "NB", "PE", "PQ", "ON", "MB", "SK", "AB", "BC", "NT", "YT", "NV"]
    while True:
        Province = input("Enter the customer province (XX): ")
        if Province == "":
            print("Error - cannot be blank.")
        elif len(Province) != 2:
            print("Error - must be 2 characters only.")
        elif Province not in ProvLst:
            print("Error - invalid province.")
        else:
            break

    Postal_code = input("Enter postal code: ").upper()
    Phone_number = input("Enter phone number (999-999-9999): ")

    
    # Gather user inputs for insurance details
    Num_InsuredCars = input("Enter number of cars insured: ")
    Num_InsuredCars = int(Num_InsuredCars)
    
    Extra_Liability_1M = input("Extra liability coverage (Y/N): ").upper()
    if Extra_Liability_1M == "N":
        Extra_Liability_1M_Cost = 0
    
    Optional_Glass_Coverage = input("Glass coverage (Y/N): ").upper()
    if Optional_Glass_Coverage == "N":
        Optional_Glass_Coverage_Cost = 0

    Optional_Loaner_Car = input("Loaner car coverage (Y/N): ").upper()
    if Optional_Loaner_Car == "N":
        Optional_Loaner_Car_Cost = 0

     # Perform required calculations.
    Insurance_Prem_1stAuto = BASIC_PREMIUM
    Insurance_Prem_Additional = (BASIC_PREMIUM * DISCOUNT_ADD_CAR) * Num_InsuredCars
    Insure_Premium = Insurance_Prem_1stAuto + Insurance_Prem_Additional
    Extra_Liability_1M_Cost = EXTRA_LIABILITY_1M_COST * Num_InsuredCars
    Glass_Coverage_Cost = GLASS_COVERAGE_COST * Num_InsuredCars
    Car_Loaner_Cost = LOANER_CAR_COST * Num_InsuredCars
    Total_Extra_Cost = Extra_Liability_1M_Cost + Glass_Coverage_Cost + Car_Loaner_Cost
    Insure_Prem_Total = Insure_Premium + Total_Extra_Cost
    Tax = HST_RATE * Insure_Prem_Total
    Total_Cost = Insure_Prem_Total + Tax


    # Previous claims
    Claims = []
    while True:
        Claim_Number = input("Enter claim number (or type 'exit' to finish): ")
        if Claim_Number.lower() == 'exit':
            break
        Claim_Date = input("Enter claim date (YYYY-MM-DD): ")
        Claim_Amount = input("Enter claim amount: ")
        Claim_Amount = float(Claim_Amount)
        Claims.append((Claim_Number, Claim_Date, Claim_Amount))
        break

    
    Monthly_Pay_Type = input("Enter the mothly payment type: Full, Monthly, or Down_Pay: ").title()
    if Monthly_Pay_Type == "Full":
        Down_Pay = 0
        Monthly_Pay = float(Total_Cost + PROCESSING_FEE_MONTH)
    if Monthly_Pay_Type == "Monthly":
        Down_Pay = float(input("Enter the Down Payment Amount: "))
        Monthly_Pay = float((Total_Cost + PROCESSING_FEE_MONTH)) / 8
    if Monthly_Pay_Type == "Down_Pay":
        Down_Pay = float(input("Enter the Down Payment Amount: "))
        Monthly_Pay = float((Total_Cost - Down_Pay + PROCESSING_FEE_MONTH)) / 8


    Invoice_Date = datetime.now()
    Invoice_Date_New = Invoice_Date.replace(day=1)
    First_Pay_Date_Cal = Invoice_Date_New + timedelta(days=32)
    First_Pay_Date = First_Pay_Date_Cal.replace(day=1)
    
    Claim_Number = 0
    Claim_Number += 1
    NEXT_POLICY_NUM += 1



    # Display results
    print()
    print()
    print("                 One Stop Insurance Policy")
    print("                      Policy #", NEXT_POLICY_NUM)
    print()
    print(f"             Current Invoice Date: {FV.FDateS(Invoice_Date):>10s}")
    print(f"               First Payment Date: {FV.FDateS(First_Pay_Date):>10s}")
    print("____________________________________________________________")
    print()
    print("                  Customer Information")
    print()
    print("               Full Name: ", CustFirstName, " ", CustLastName)
    print("            Phone Number: ", Phone_number)
    print("                 Address: ", Address)
    print("                    City: ", City, " ", Province, " ", Postal_code)
    print()
    print("____________________________________________________________")
    print()
    print("                 Premium Information")
    print()
    print(f"          Number of Cars: {Num_InsuredCars}")
    print(f"         Extra Liability: {Extra_Liability_1M}  {FV.FDollar2(Extra_Liability_1M_Cost):>10s}")
    print(f"          Glass Coverage: {Optional_Glass_Coverage}  {FV.FDollar2(Glass_Coverage_Cost):>10s}")
    print(f"              Loaner Car: {Optional_Loaner_Car}  {FV.FDollar2(Car_Loaner_Cost):>10s}")
    print("         _________________________________")
    print(f"           Total Premium:    {FV.FDollar2(Insure_Prem_Total):>10s}")
    print(f"                     HST:    {FV.FDollar2(Tax):>10s}")
    print("         _________________________________")
    print(f"              Total Cost:    {FV.FDollar2(Total_Cost):>10s}")
    print()
    print("____________________________________________________________")
    print()
    print("                 Payment Details")
    print()
    print(f"          Payment Method:   {Monthly_Pay_Type}")
    print(f"            Down Payment:   {Down_Pay}")
    print(f"         Monthly Payment:   {Monthly_Pay}")
    print("____________________________________________________________")
    print()
    print("                 Claim(s) Details")
    print()
    print("         Claim #     Claim Date      Amount")
    print("------------------------------------------------------------")
    print(f"           {Claim_Number}         {FV.FDateS(Invoice_Date):>10s}     {FV.FDollar2(Total_Cost):>10s}")
    print(f"           {Claim_Number}         {FV.FDateS(Invoice_Date):>10s}     {FV.FDollar2(Total_Cost):>10s}")
    print(f"           {Claim_Number}         {FV.FDateS(Invoice_Date):>10s}     {FV.FDollar2(Total_Cost):>10s}")
    print("____________________________________________________________")
    print()
    print("      Thank you for choosing One Stop Insurance Company!    ")


    # Write the claim values into the OneStop data file for record keeping
    for _ in range(5):  # Change to control no. of 'blinks'
        print('Saving claim data ...', end='\r')
        time.sleep(.3)  # Used to create blinking effect
        # Clears entire line and the carriage returns
        sys.stdout.write('\033[2K\r')
        time.sleep(.3)

    
    f = open('OneStop.dat', 'w')
    # All values written to file must be a string.  If there is a numeric value, used the str() function to convert.
    f.write("{}\n".format(str(NEXT_POLICY_NUM)))
    f.write("{}\n".format(str(BASIC_PREMIUM)))
    f.write("{}\n".format(str(DISCOUNT_ADD_CAR)))
    f.write("{}\n".format(str(Extra_Liability_1M_Cost)))
    f.write("{}\n".format(str(Glass_Coverage_Cost)))
    f.write("{}\n".format(str(Car_Loaner_Cost)))
    f.write("{}\n".format(str(Tax)))
    f.write("{}\n".format(str(PROCESSING_FEE_MONTH)))
    f.close()

    

    f = open("Claims List.dat", "a")

    # All values written to file must be a string.  If there is a numeric value, used the str() function to convert.
    f.write("{}, ".format(str(Claim_Number)))
    f.write("{}, ".format(str(Invoice_Date)))
    f.write("{}, ".format(float(Total_Cost)))

    f.close()

    # Display message to indicate the data is saved.
    print()
    print("Claim data successfully saved ...", end='\r')
    time.sleep(1)  # To create the blinking effect
    sys.stdout.write('\033[2K\r') # Clears the entire line and carriage returns

    NEXT_POLICY_NUM += 1


    # Any housekeeping duties at the end of the program.

    # Write the default values back to the Defaults.dat file
    f = open('Defaults.dat', 'w')
    f.write("{}\n".format(str(NEXT_POLICY_NUM)))
    f.write("{}\n".format(str(BASIC_PREMIUM)))
    f.write("{}\n".format(str(DISCOUNT_ADD_CAR)))
    f.write("{}\n".format(str(EXTRA_LIABILITY_1M_COST)))
    f.write("{}\n".format(str(Glass_Coverage_Cost)))
    f.write("{}\n".format(str(Car_Loaner_Cost)))
    f.write("{}\n".format(str(Tax)))
    f.write("{}\n".format(str(PROCESSING_FEE_MONTH)))
    f.close()

    # Use the following to continue the loop or break the loop
    while True:
        Continue_Prompt = input("Do you want to process another loan (Y or N): ").upper()
        if Continue_Prompt == "N":
            break


    # End program